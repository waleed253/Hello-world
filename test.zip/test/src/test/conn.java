package test;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.SQLException;  
import java.sql.Statement;
import javax.swing.JOptionPane;
   
public class conn {  
     /** 
     * Connect to a sample database 
     */  
       Connection c;
    Statement s;

    public conn() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql:///semesterproject","root","");
            s=c.createStatement();
            
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }
  
}